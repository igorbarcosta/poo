#!/usr/bin/env sh
cd -- "$(dirname -- "$0")" || exit 1
exec ./gradlew --console=plain :run "$@"
