# Prova da Unidade 02 — primeira versão para revisão

Recorte confirmado: conteúdos até a Aula 18, sem tratamento de exceções.
Instrumento proposto: vinte questões objetivas de 5 pontos, total de 100 pontos,
com duração de referência de 90 minutos. Esta versão aguarda avaliação do professor.

## Arquivos para leitura

- `unidade_02.typ`: fonte Typst completa, com o Java do cenário e as vinte questões.
- `unidade_02.pdf`: prévia compilada de sete páginas, sem o gabarito.
- `gabarito.md`: respostas comentadas, em arquivo exclusivo do professor.
- `java/`: nove classes e interfaces do cenário em arquivos Java compiláveis.
- `blueprint.md`: recorte, matriz de evidências, pesos e decisões de elaboração.
- `base.md`: conteúdo semântico da prova, correspondente à fonte Typst.
- `base-review.md`: revisão do próprio autor, com o percurso de resolução dos itens.
- `workflow.yaml`: direcionamento registrado e estado de elaboração; sem aprovação de base.
- `preview/`: preview HTML da base e imagens das páginas para inspeção.

## Compilar

Na pasta deste arquivo:

```bash
typst compile unidade_02.typ unidade_02.pdf
javac -d out java/*.java
```

O Typst utiliza a fonte Ubuntu Mono para os códigos. A composição segue
`avaliacoes/provas/unidade_01.typ`: A4, cabeçalho institucional, campos Nome/Nota,
quadro de respostas, questões em duas colunas e caixas de código numeradas.
O import `codepoint` do modelo anterior não foi copiado, pois nenhum de seus
componentes é utilizado nesta composição.

As classes Java representam o cenário; não incluem janela, framework ou `main`.
Os trechos independentes das questões fornecem as chamadas a analisar.

## Verificação realizada

- Compilação do cenário com OpenJDK 21 em contêiner local sem rede.
- Sessenta verificações de execução para cenários, estados, delegação,
  capacidades, alternativas da Q12 e defeitos apresentados nas Q18 e Q20.
- Compilação isolada das quatro chamadas da Q5: I e III aceitas; II e IV rejeitadas.
- Contraexemplo para Q19: uma primeira chamada com outra partida e uma segunda
  com a partida esperada passam nos dois asserts, confirmando o limite do teste.
- Compilação Typst 0.15.1, conferência das sete páginas e inspeção visual.
- Preview HTML atualizado e workflow validado pelas ferramentas do Docemas.

Código e questões permanecem sujeitos à revisão pedagógica do professor.
O site e o protótipo do jogo não foram modificados. Não houve commit ou publicação.
