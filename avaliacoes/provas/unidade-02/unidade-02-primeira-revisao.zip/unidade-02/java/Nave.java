public class Nave {
    private Partida partida;
    private Disparo disparo;
    private int recarga;

    public Nave(Partida partida,
                Disparo disparo) {
        this.partida = partida;
        this.disparo = disparo;
        recarga = 0;
    }

    public void atualizar(boolean pressionado) {
        if (partida.terminou()) {
            return;
        }
        if (pressionado && recarga == 0) {
            disparo.disparar(partida);
            recarga = 3;
        }
        if (recarga > 0) {
            recarga--;
        }
    }

    public int getRecarga() {
        return recarga;
    }
}
