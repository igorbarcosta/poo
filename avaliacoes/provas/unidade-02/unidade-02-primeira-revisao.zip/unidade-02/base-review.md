# Revisão da base — primeira versão da Unidade 02

Revisão do próprio autor, sem alegação de auditoria independente ou aprovação humana. A solução comentada completa está em gabarito.md; o mapa de evidências e de ganho marginal está em blueprint.md. A solicitação explícita do professor autoriza a distribuição preliminar em Typst/PDF para esta revisão.

## Mapa e teste de remoção

Vinte unidades independentes, 5 pontos cada, total 100. A remoção de cada unidade perde a inferência específica descrita em blueprint.md; relações mais próximas foram diferenciadas: Q4 integra herança ao despacho, Q5 examina disponibilidade; Q8 examina compartilhamento, Q9 reatribuição, Q10 profundidade; Q12 acrescenta requisito novo, em vez de copiar um corpo já fornecido; Q18 seleciona cenário, Q19 limita a conclusão de um teste e Q20 localiza regressão de regra herdada.

## Percurso do estudante e carga observável

| ID | Primeiro passo | Fontes | Estados, regras e decisões coordenados | Erros representados nos distratores |
| --- | --- | --- | --- | --- |
| q-u02-001 | Localizar campos e métodos que os alteram. | Partida, Nave e Arma. | Relacionar três donos de estado; sem valores intermediários. | Troca de donos e responsabilidades. |
| q-u02-002 | Seguir perderVida desde vidas=3. | Partida.perderVida e registrarTiros. | Cinco tentativas; reconhecer guarda após a terceira; consultar três resultados. | Guarda ignorada, vidas negativas ou fim não registrado. |
| q-u02-003 | Criar uma tabela das quatro atualizações. | Nave.atualizar e ArmaSimples. | Coordenar pressionado, recarga e tiros; registrar quatro pares. | Decremento antes/depois, atraso de uma atualização ou ausência de espera. |
| q-u02-004 | Seguir a chamada ao Disparo guardado. | Nave, Arma e ArmaDupla. | Uma referência e duas resoluções: método herdado e operação sobrescrita. | Interface com corpo inexistente, troca do destinatário ou criação extra. |
| q-u02-005 | Ler o tipo declarado de d e c. | Disparo e Contabilizavel. | Quatro chamadas analisadas separadamente; dois contratos. | Usar classe concreta para ampliar operações da referência. |
| q-u02-006 | Percorrer as duas entradas da lista. | Arma, subclasses e laço local. | Duas chamadas; três totais solicitados; sem reatribuição. | Fórmula única, contagem global ou contador não herdado. |
| q-u02-007 | Conferir o parâmetro do construtor de Nave. | Disparo e Nave. | Um novo colaborador; localizar o ponto de montagem. | Dependência concreta, teste de tipo ou herança obrigatória. |
| q-u02-008 | Identificar a arma única e as duas partidas. | Trecho local, Nave e Arma. | Duas chamadas; um contador compartilhado e dois totais separados. | Cópia do colaborador, contador global de tiros ou atribuição à partida errada. |
| q-u02-009 | Marcar qual referência foi guardada na construção. | Trecho local e DisparoRepetido. | Uma reatribuição posterior; dois acionamentos do objeto anterior. | Campo acompanhar variável local. |
| q-u02-010 | Desenhar as duas camadas e a arma. | Trecho local, DisparoRepetido e ArmaDupla. | Dois níveis; quatro chamadas finais; distinguir 8 tiros de 4 acionamentos. | Contar camadas em lugar de chamadas, perder multiplicação ou misturar contadores. |
| q-u02-011 | Ler a única atribuição substituída. | Construtor de DisparoRepetido. | Um campo e um argumento ignorado; comparar comportamento configurado. | Confundir criação por objeto, estado estático ou alteração da interface. |
| q-u02-012 | Inventariar destinatário, argumento e adicional. | Requisito local e API de Disparo/Partida. | Três critérios explícitos: uma chamada à base, mesma partida, adicional posterior. | Argumento substituído, base ignorada, duplicação ou resultado fixo. |
| q-u02-013 | Separar referência de instanciação. | Arma e ArmaSimples. | Uma operação abstrata e duas concretas. | Instanciar base, não herdar corpo ou impedir uso por referência abstrata. |
| q-u02-014 | Ler os dois construtores encadeados. | ArmaDupla e Arma. | Um objeto e um contador; não há chamadas a operação sobrescrita na construção. | Segundo objeto, contador duplicado/global ou inicialização adiada. |
| q-u02-015 | Relacionar o requisito ao campo do repetidor. | DisparoRepetido e interface Disparo. | Combinar o mesmo comportamento de repetição com dois colaboradores possíveis. | Herança de interface como herança de campos, fusão de objetos ou alteração de classe. |
| q-u02-016 | Identificar o objeto concreto alcançado. | ArmaDupla, Arma e Contabilizavel. | Um teste de capacidade seguido de cast compatível; sem erro de execução. | Cast criar, transformar ou acrescentar capacidade. |
| q-u02-017 | Examinar a classe do objeto externo. | DisparoRepetido e Contabilizavel. | Distinguir objeto testado de seu campo base. | Transferir capacidade ao invólucro ou removê-la do colaborador. |
| q-u02-018 | Comparar original e uma única atribuição defeituosa. | Nave.atualizar e cenários alternativos. | Para cada alternativa, dois rastreamentos curtos; só D separa os resultados. | Cenário com apenas um disparo ou comando solto não ativa o defeito. |
| q-u02-019 | Conferir o que cada assert observa. | DisparoRegistro e teste local. | Duas observações: contagem e último argumento; considerar primeiro argumento não guardado. | Generalizar última observação para todo o histórico ou confundir registro com tiros. |
| q-u02-020 | Identificar a regra omitida pela sobrescrita. | Novo corpo e Arma.disparar/getAcionamentos. | Uma chamada; dois tiros corretos e contador zero; escolher observação relevante. | Testar efeito preservado em vez da regra regredida. |

## Determinação e representação

- Cada questão tem um resultado pretendido e uma alternativa correta; a solução foi confrontada com os corpos de método. As questões 2–20 com código dependem de construções Java ou APIs já trabalhadas; as operações novas do domínio estão declaradas no material.
- Os imports, os arquivos separados sem package, a ausência de null e a independência dos trechos vêm antes do primeiro código. Não se depende de ordem de execução de framework.
- Q5 pede analisar chamadas isoladamente; assim uma chamada inválida não impede a análise das demais. Não usa regras de protected entre pacotes.
- Q12 explicita os três critérios antes das cinco alternativas comparáveis. As duas linhas variáveis aparecem como código; não há assinaturas repetidas.
- Q18 exige comparar cinco cenários com uma mutação específica. Os cenários são curtos e locais. É uma das questões mais trabalhosas, junto com Q10 e Q19.
- Q19 não afirma que a última referência prova todo o histórico; o contraexemplo de primeira partida diferente confirma o limite.
- Não há afirmações que entreguem a saída numérica de outra questão. Regras do próprio cenário reaparecem para analisar operações diferentes, sobretudo na transferência para testes.

## Passagem global

O arco começa pelo estado conhecido, passa por contratos e referências, combina comportamentos, analisa herança e termina na verificação. O domínio não exige jogar nem conhecer geometria ou bibliotecas. Há navegação para nove tipos pequenos nas duas páginas de referência; esse custo existe, sobretudo em Q4, Q8 e Q10. A paginação mantém as questões completas, com duas questões por coluna. Não há alternativas ou enunciados partidos entre páginas.

O tempo de 90 minutos é uma estimativa a confirmar pelo professor. A prova contém mais comparação e diagnóstico que o instrumento antigo. A primeira revisão deve observar se o volume de leitura e Q10/Q19 estão proporcionais ao repertório da turma.

## Ciclos e verificações

1. Primeira revisão: uma questão de comparação repetia literalmente a implementação fornecida. Foi substituída pela evolução DisparoComExtra, mantendo os três critérios locais. Os getters de Partida foram compactados sem alteração semântica para manter o código de referência em duas páginas.
2. Validação técnica: consultar README.md desta pasta para os resultados de compilação do cenário, execução dos cenários e conferência da renderização.

Nenhum gate de aprovação foi registrado. A presente revisão não é evidência de maturação independente nem liberação para impressão.
